# FNRASEC Winlink Templates

## Release note

### 2025-04-07

Cette version contient une nouvelle mouture des formulaires :

* Message Exercice - version 6.0.14
* Message de commandement - version 1.0.4
* Accusé de réception - version 2.1.44
* État des Réseaux Saisie - version 6.1

::: warn
Le formulaire "État des réseaux" est toujours sous l'ancien format et nécessite encore les fichiers des dossiers '/inc' et '/Bouton Aide'

:::